#ifndef __EIGHTIES_GAME__
#define __EIGHTIES_GAME__

////// EIGHTIES GAME //////////////////////////////////////////////////////
//
// Most of this code is from Javidx's olcConsoleGameEngine.
// We have its most basic functionality here, plus some functions
// that allow students to use the class without inheritance.
// 
// Students need to start this game before they have the knowledge
// to support the concepts and syntax of inheritance and polymorphism.
//
///////////////////////////////////////////////////////////////////////////

#pragma comment(lib, "winmm.lib")
#include <Windows.h>
#include <chrono>
#include <functional>
#include <algorithm>
#include "eightiesEnums.h"

using namespace std;
using namespace std::chrono;

class OlcBits
{
public:
  int screenWidth;
  int screenHeight;
  int fontWidth = 12;
  int fontHeight = 12;
  time_point<system_clock> tp1 = system_clock::now();
  time_point<system_clock> tp2 = system_clock::now();

  HANDLE console;
  HANDLE consoleIn;
  HANDLE originalConsole;
  SMALL_RECT rectWindow;
  CHAR_INFO *bufScreen;


  int Error(const wchar_t *msg)
  {
    wchar_t buf[256];
    FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), buf, 256, NULL);
    SetConsoleActiveScreenBuffer(originalConsole);
    //wprintf(L"ERROR: %s\n\t%s\n", msg, buf); FIX
    return 0;
  }

  static BOOL CloseHandler(DWORD evt)
  {
    // Note this gets called in a seperate OS thread, so it must
    // only exit when the game has finished cleaning up, or else
    // the process will be killed before OnUserDestroy() has finished
    if (evt == CTRL_CLOSE_EVENT)
    {
      //m_bAtomActive = false;

      // Wait for thread to be exited
      //std::unique_lock<std::mutex> ul(m_muxGame);
      //m_cvGameFinished.wait(ul);
    }
    return true;
  }

  int setupConsole(int width = 20, int height = 20, int characterWidth = 12, int characterHeight = 12)
  {
    console = GetStdHandle(STD_OUTPUT_HANDLE);
    consoleIn = GetStdHandle(STD_INPUT_HANDLE);

    fontWidth = characterWidth;
    fontHeight = characterHeight;
    if (console == INVALID_HANDLE_VALUE)
      return Error(L"Bad Handle");

    screenWidth = width;
    screenHeight = height;

    // Update 13/09/2017 - It seems that the console behaves differently on some systems
    // and I'm unsure why this is. It could be to do with windows default settings, or
    // screen resolutions, or system languages. Unfortunately, MSDN does not offer much
    // by way of useful information, and so the resulting sequence is the reult of experiment
    // that seems to work in multiple cases.
    //
    // The problem seems to be that the SetConsoleXXX functions are somewhat circular and 
    // fail depending on the state of the current console properties, i.e. you can't set
    // the buffer size until you set the screen size, but you can't change the screen size
    // until the buffer size is correct. This coupled with a precise ordering of calls
    // makes this procedure seem a little mystical :-P. Thanks to wowLinh for helping - Jx9

    // Change console visual size to a minimum so ScreenBuffer can shrink
    // below the actual visual size
    rectWindow = { 0, 0, 1, 1 };
    SetConsoleWindowInfo(console, TRUE, &rectWindow);

    // Set the size of the screen buffer
    COORD coord = { (short)screenWidth, (short)screenHeight };
    if (!SetConsoleScreenBufferSize(console, coord))
      Error(L"SetConsoleScreenBufferSize");

    // Assign screen buffer to the console
    if (!SetConsoleActiveScreenBuffer(console))
      return Error(L"SetConsoleActiveScreenBuffer");

    // Set the font size now that the screen buffer has been assigned to the console
    CONSOLE_FONT_INFOEX cfi;
    cfi.cbSize = sizeof(cfi);
    cfi.nFont = 0;
    cfi.dwFontSize.X = fontWidth;
    cfi.dwFontSize.Y = fontHeight;
    cfi.FontFamily = FF_DONTCARE;
    cfi.FontWeight = FW_NORMAL;

    /*	DWORD version = GetVersion();
      DWORD major = (DWORD)(LOBYTE(LOWORD(version)));
      DWORD minor = (DWORD)(HIBYTE(LOWORD(version)));*/

      //if ((major > 6) || ((major == 6) && (minor >= 2) && (minor < 4)))		
      //	wcscpy_s(cfi.FaceName, L"Raster"); // Windows 8 :(
      //else
      //	wcscpy_s(cfi.FaceName, L"Lucida Console"); // Everything else :P

      //wcscpy_s(cfi.FaceName, L"Liberation Mono");
    wcscpy_s(cfi.FaceName, L"Consolas");
    if (!SetCurrentConsoleFontEx(console, false, &cfi))
      return Error(L"SetCurrentConsoleFontEx");

    // Get screen buffer info and check the maximum allowed window size. Return
    // error if exceeded, so user knows their dimensions/fontsize are too large
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    if (!GetConsoleScreenBufferInfo(console, &csbi))
      return Error(L"GetConsoleScreenBufferInfo");
    if (screenHeight > csbi.dwMaximumWindowSize.Y)
      return Error(L"Screen Height / Font Height Too Big");
    if (screenWidth > csbi.dwMaximumWindowSize.X)
      return Error(L"Screen Width / Font Width Too Big");

    // Set Physical Console Window Size
    rectWindow = { 0, 0, (short)screenWidth - 1, (short)screenHeight - 1 };
    if (!SetConsoleWindowInfo(console, TRUE, &rectWindow))
      return Error(L"SetConsoleWindowInfo");

    // Set flags to allow mouse input		
    if (!SetConsoleMode(consoleIn, ENABLE_EXTENDED_FLAGS | ENABLE_WINDOW_INPUT | ENABLE_MOUSE_INPUT))
      return Error(L"SetConsoleMode");

    // Allocate memory for screen buffer
    bufScreen = new CHAR_INFO[screenWidth*screenHeight];
    memset(bufScreen, 0, sizeof(CHAR_INFO) * screenWidth * screenHeight);

    SetConsoleCtrlHandler((PHANDLER_ROUTINE)CloseHandler, TRUE);
    return 1;
  }

  bool keyIsDown(int key) {
    return (GetAsyncKeyState(key) != 0);
  }

  void drawBufferToConsole()
  {
    WriteConsoleOutput(console, bufScreen, { (short)screenWidth, (short)screenHeight }, { 0,0 }, &rectWindow);
  }

  void drawCharacter(int x, int y, short c = 0x2588, Color col = Color::FG_WHITE)
  {
    if (x >= 0 && x < screenWidth && y >= 0 && y < screenHeight)
    {
      bufScreen[y * screenWidth + x].Char.UnicodeChar = c;
      bufScreen[y * screenWidth + x].Attributes = (short)col;
    }
  }

  float getTimeSinceLastFrame()
  {
    tp2 = std::chrono::system_clock::now();
    std::chrono::duration<float> elapsedTime = tp2 - tp1;
    tp1 = tp2;
    return(elapsedTime.count());

  }

  void drawWString(int x, int y, std::wstring c, Color fgColor = Color::FG_WHITE, Color bgColor = Color::BG_BLACK)
  {
    for (size_t i = 0; i < c.size(); i++)
    {
      bufScreen[y * screenWidth + x + i].Char.UnicodeChar = c[i];
      bufScreen[y * screenWidth + x + i].Attributes = (short)fgColor | (short)bgColor;
    }
  }

  void drawString(int x, int y, string text, Color fgColor = Color::FG_WHITE, Color bgColor = Color::BG_BLACK)
  {
    wstring wText(text.begin(), text.end());      // Create a wstring with contents of original string 
    drawWString(x, y, wText, fgColor, bgColor);
  }

  void drawRow(int y, Color color = Color::FG_WHITE)
  {
    for (int x = 0; x < screenWidth; x++)
    {
      drawCharacter(x, y, 0x2588, color);
    }
  }

  void drawPixel(int x, int y, Color colour = Color::FG_WHITE)
  {
    drawCharacter(x, y, 0x2588, colour);
  }

  void drawRectFilled(int xTopLeft, int yTopLeft, int width, int height, Color color = BG_WHITE)
  {
    for (int row = 0; row < height; row++)
    {
      for (int column = 0; column < width; column++)
      {
        drawPixel(column+xTopLeft, row+yTopLeft, color);
      }
    }
  }

  void drawRectEmpty(int xTopLeft, int yTopLeft, int width, int height, Color color = BG_WHITE)
  {
    for (int row = 0; row <= height; row++)
    {
       drawPixel(xTopLeft, yTopLeft+row, color);
       drawPixel(xTopLeft + width, yTopLeft + row, color);
    }
    for (int col = 0; col <= width; col++)
    {
      drawPixel(xTopLeft + col, yTopLeft, color);
      drawPixel(xTopLeft + col, yTopLeft + height, color);
    }
  }

  bool isReverse(Direction newDir, Direction oldDir)
  {
    bool reverse = false;

    switch (newDir)
    {
    case UP:
      reverse = (oldDir == DOWN);
      break;
    case DOWN:
      reverse = (oldDir == UP);
      break;
    case LEFT:
      reverse = (oldDir == RIGHT);
      break;
    case RIGHT:
      reverse = (oldDir == LEFT);
      break;
    }
    return reverse;
  }


};    // END CLASS OLCBITS ////////////////////////////////////////////////////

OlcBits engine;

int setupWindow (int w, int h, int pw, int ph) 
{
  return engine.setupConsole(w, h, pw, ph);
}

void renderWindow() 
{
  engine.drawBufferToConsole();
}

float getTimeElapsed() {
  return engine.getTimeSinceLastFrame();
}

void printWString(int x, int y, std::wstring aWString, Color fgColor = Color::FG_WHITE, Color bgColor = Color::BG_BLACK) 
{
  engine.drawWString(x, y, aWString, fgColor, bgColor);
}

void printString(int x, int y, string aString, Color fgColor = Color::FG_WHITE, Color bgColor = Color::BG_BLACK)
{
  engine.drawString(x, y, aString, fgColor, bgColor);
}

void drawPixel(int x, int y, Color color)
{
  engine.drawPixel(x, y, color);
}

bool keyIsDown(int key) {
  return(engine.keyIsDown(key));
}

void drawRectFilled(int xTopLeft, int yTopLeft, int width, int height, Color color = FG_WHITE)
{
  engine.drawRectFilled(xTopLeft, yTopLeft, width, height, color);
}

void drawRectEmpty(int xTopLeft, int yTopLeft, int width, int height, Color color = FG_WHITE)
{
  engine.drawRectEmpty(xTopLeft, yTopLeft, width, height, color);
}

bool isReverse(Direction newDir, Direction oldDir)
{
  return engine.isReverse(newDir, oldDir);
}


#endif