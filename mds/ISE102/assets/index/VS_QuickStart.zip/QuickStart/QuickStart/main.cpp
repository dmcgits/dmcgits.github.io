#include <iostream>
#include <string>
using namespace std;

int main()
{
  // Code here.

  return(0);
}