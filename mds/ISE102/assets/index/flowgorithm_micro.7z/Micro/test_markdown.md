## Markdown

That's right.

* Here's a list
* there's a list

**I'm bold**.

I'm _italic_.

> I'm quoting right now.

hello i am some text

```cpp

#include <iostream>

int main()
{
	// Some c++
	std::cout << "\tYep, c++ here." <<  std::endl;
	
}

```