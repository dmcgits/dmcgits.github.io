#include <iostream>
#include <string>
#include <vector>
#include "eightiesGame.h"

using namespace std;

int main()
{
  float timeElapsed = 0.0f;
  float gameExited = false;
  setupWindow(30, 30, 16, 16);

  while ( !gameExited )
  {
    drawPixel(14, 14, (short)Color::FG_GREEN);
    timeElapsed = getTimeElapsed();
    printWString(10, 10, to_wstring(1.0f/timeElapsed), (short)Color::FG_YELLOW);
    renderWindow();
  }

  return 0;
}