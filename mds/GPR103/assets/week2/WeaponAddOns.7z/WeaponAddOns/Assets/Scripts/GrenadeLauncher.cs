﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class GrenadeLauncher : GunAddon {

	// Use this for initialization
	void Start () {
    Debug.Log("I spew pineapples");	
	}
	
}
