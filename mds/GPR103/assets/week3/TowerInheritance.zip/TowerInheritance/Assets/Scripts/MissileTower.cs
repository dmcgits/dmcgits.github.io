﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MissileTower : Tower
{

    private int _firingRate = 1;
    private float _damagePerProjectile = 1.0f;
    
    private const int NUM_PODS = 9;

    // Use this for initialization
    void Start()
    {
        Debug.Log("I am Missile.");
    }

    public override void Build(Vector2 position)
    {
        Debug.Log(gameObject.name + "Missile.Build() here and I didn't call base.");
    }

    public float DamagePerProjectile
    {
        get { return _damagePerProjectile; }
    }

    public int FiringRate
    {
        get { return _firingRate;  }
    }

    protected void Fire()
    {
        Debug.Log("Fire!");
    }
}
