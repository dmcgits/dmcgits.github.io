﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TowerMaster : MonoBehaviour {

    public List<Tower> towers;

	void Start () {

        Debug.Log("TowerMaster says hi");
        Debug.Log("towers.Count = " + towers.Count);
        int i=0;

        // do this until we run out of towers
        while (i < towers.Count)
        {
            // Call Build on all our towers
            towers[i].Build(new Vector2(1.0f, 2.0f));
            i++;
        }
    }
}
