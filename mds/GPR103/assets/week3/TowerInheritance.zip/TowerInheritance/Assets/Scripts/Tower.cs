﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tower : MonoBehaviour {

    protected Vector2 _position;

    protected int _health       = 100;
    protected int _level        = 1;


    public virtual void Build(Vector2 position)
    {
        // Didn't need virtual?
        Debug.Log(gameObject.name + ": Tower.Build is setting position");
        _position = position;
    }

    virtual public void LevelUp()
    {
       // Hey buddy override this when you make a new tower
    }
	
    public int CurrentLevel
    {
        get { return _level; }
    }

    public int Health
    {
        get { return _health; }
        set { _health = value; }
    }

    private void Collapse()
    {
        Debug.Log("Collapse.");
    }
}
