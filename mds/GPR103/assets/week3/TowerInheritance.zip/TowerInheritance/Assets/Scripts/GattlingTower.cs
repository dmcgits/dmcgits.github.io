﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GattlingTower : Tower {

    protected int _turrets = 1;
    protected int _damagePerSecond = 8;

    // Use this for initialization
    void Start() {
        Debug.Log("I am Gattling.");

    }

    public override void Build(Vector2 position)
    {
        // Use base to call Build on Tower
        base.Build(position);

        Debug.Log("Gattling.Build() here, just logging.");
    }

    public int DamagePerSecond
    {
        get { return _damagePerSecond; }
    }
}
